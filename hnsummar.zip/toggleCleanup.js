summarizer_buttons = document.querySelectorAll("button.summarizerbutton")

for (let i = 0; i < summarizer_buttons.length; i++) {
    summarizer_buttons[i].remove()
}